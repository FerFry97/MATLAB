function Ti64_MeasuredBeta_Standalone()
% Independent measured beta pole and inverse pole figures. NO reconstruction.
% Works directly from Oxford AZtec .ctf with MTEX started.
    if exist('EBSD','class') ~= 8
        error('Please start MTEX before running this script.');
    end
    [fn,fp]=uigetfile('*.ctf','Select Oxford EBSD original CTF');
    if isequal(fn,0), return; end
    raw=EBSD.load(fullfile(fp,fn),'interface','ctf', ...
        'convertEuler2SpatialReferenceFrame');
    beta=raw('Titanium cubic');
    [~,sample]=fileparts(fn);
    outFolder=fullfile(fp,[sample '_MeasuredBeta_PF_IPF']);
    if ~isfolder(outFolder), mkdir(outFolder); end
    [f26,f27]=plotMeasuredBetaPFandIPF(beta,10*degree,outFolder);
    if ~isempty(f27), figure(f27); drawnow; end
    fprintf('\nMeasured beta PF and IPF figures saved to:\n%s\n',outFolder);
end



%% ===== STANDALONE ORIGINAL MEASURED BETA: 3 PF + 3 IPF =====
function [figPF,figIPF] = plotMeasuredBetaPFandIPF(betaMeasured,halfwidth,outFolder)
% betaMeasured MUST be EBSD('Titanium cubic') from the original CTF.
% Figure 26: pole figures of {110}, {200}, {211} beta.
% Figure 27: inverse pole figures for the specimen directions X, Y, Z.
% These describe the original retained beta, NOT reconstructed prior beta.
% All three panels in each figure have their own explicit axes.
    figPF=[]; figIPF=[];
    n=length(betaMeasured);
    if n==0
        warning('No measured beta is indexed in the original CTF: figures 26/27 skipped.');
        return;
    end
    cs=betaMeasured.CS;
    odf=calcDensity(betaMeasured.orientations,'halfwidth',halfwidth,'silent');
    h=[Miller(1,1,0,cs),Miller(2,0,0,cs),Miller(2,1,1,cs)];
    labels={'{110}','{200}','{211}'};
    peakVals=nan(3,1); xyz=nan(3,3);
    tilt=nan(3,1); az=nan(3,1);

    %% Figure 26 - measured beta ONLY: three pole figures.
    figPF=figure('Name','26 | ORIGINAL MEASURED beta - 3 PFs', ...
        'NumberTitle','off','Color','white','Visible','on', ...
        'WindowStyle','normal','Tag','Ti64_MeasuredBeta_3PF_Fig26', ...
        'Units','pixels','Position',[180 160 1450 560]);
    axPF=gobjects(1,3);
    for k=1:3
        axPF(k)=subplot(1,3,k,'Parent',figPF);
        [peakVals(k),xyz(k,:),tilt(k),az(k)]=pfMaxWithDirection(odf,h(k));
        plotPDF(odf,h(k),'antipodal','contourf','parent',axPF(k));
        title(axPF(k),sprintf('Measured beta %s | max %.2f MRD', ...
            labels{k},peakVals(k)),'FontSize',11,'Interpreter','none');
    end
    drawnow;
    if any(~isgraphics(axPF,'axes'))
        warning('Figure 26: unexpected axes replacement by MTEX.');
    end
    tops=nan(3,1);
    for k=1:3
        lim=get(axPF(k),'CLim');
        tops(k)=lim(2);
    end
    allM=[tops(isfinite(tops));peakVals(isfinite(peakVals))];
    if isempty(allM), scale=1; else, scale=max(allM); end
    if ~isfinite(scale) || scale<=0, scale=1; end
    for k=1:3, set(axPF(k),'CLim',[0 scale]); end
    c=colorbar(axPF(3),'eastoutside'); ylabel(c,'MRD');
    try
        sgtitle(figPF,sprintf('ORIGINAL measured beta (CTF): %d indexed pixels | PF halfwidth %.1f deg', ...
            n,halfwidth/degree),'FontWeight','bold');
    catch
    end
    drawnow;
    T=table(labels(:),peakVals,xyz(:,1),xyz(:,2),xyz(:,3),tilt,az, ...
        repmat(n,3,1),repmat(halfwidth/degree,3,1), ...
        'VariableNames',{'PoleFamily','MaxMRD','PeakDir_X','PeakDir_Y', ...
        'PeakDir_Z','TiltFromZ_deg','AzimuthFromX_deg', ...
        'EBSD_Pixels','ODFHalfwidth_deg'});
    disp('===== ORIGINAL MEASURED BETA - THREE POLE FIGURE PEAKS =====');
    disp(T);
    writetable(T,fullfile(outFolder,'26_MeasuredBeta_PF_MaxMRD.csv'));
    exportgraphics(figPF,fullfile(outFolder,'26_MeasuredBeta_3PF.png'),'Resolution',300);
    savefig(figPF,fullfile(outFolder,'26_MeasuredBeta_3PF.fig'));

    %% Figure 27 - measured beta ONLY: three INVERSE pole figures.
    figIPF=figure('Name','27 | ORIGINAL MEASURED beta - IPF-X/Y/Z', ...
        'NumberTitle','off','Color','white','Visible','on', ...
        'WindowStyle','normal','Tag','Ti64_MeasuredBeta_3IPF_Fig27', ...
        'Units','pixels','Position',[220 205 1450 560]);
    axesIPF=gobjects(1,3);
    dirs=[xvector,yvector,zvector];
    dlabels={'X','Y','Z'};
    for k=1:3
        axesIPF(k)=subplot(1,3,k,'Parent',figIPF);
        plotIPDF(odf,dirs(k),'contourf','parent',axesIPF(k));
        title(axesIPF(k),sprintf('Measured beta | IPF-%s',dlabels{k}), ...
            'FontSize',11,'Interpreter','none');
    end
    drawnow;
    limits=nan(3,1);
    for k=1:3
        lim=get(axesIPF(k),'CLim');
        limits(k)=lim(2);
    end
    upper=limits(isfinite(limits));
    if isempty(upper), upper=1; else, upper=max(upper); end
    if ~isfinite(upper) || upper<=0, upper=1; end
    for k=1:3, set(axesIPF(k),'CLim',[0 upper]); end
    c=colorbar(axesIPF(3),'eastoutside'); ylabel(c,'MRD');
    try
        sgtitle(figIPF,sprintf('Inverse pole density: MEASURED beta only | %d indexed pixels',n), ...
            'FontWeight','bold');
    catch
    end
    drawnow;
    exportgraphics(figIPF,fullfile(outFolder,'27_MeasuredBeta_IPF_XYZ.png'),'Resolution',300);
    savefig(figIPF,fullfile(outFolder,'27_MeasuredBeta_IPF_XYZ.fig'));
    fprintf('Figure 26: 3 measured beta PF saved.\n');
    fprintf('Figure 27: 3 measured beta IPF saved.\n');
end

function [peakMRD,peakXYZ,tiltDeg,azDeg] = pfMaxWithDirection(odf,h)
% Evaluates the maximum of the spherical POLE DENSITY FUNCTION, not the ODF.
% [value,direction] = max(calcPDF(odf,h)) is supported by MTEX S2Fun.max.
% The corresponding antipodal vector is flipped into the upper hemisphere,
% i.e., +Z-facing direction in the EBSD specimen reference frame.
    peakMRD = NaN;
    peakXYZ = [NaN NaN NaN];
    tiltDeg = NaN;
    azDeg = NaN;
    try
        pdfFun = calcPDF(odf,h);
        [peakMRD,peakDir] = max(pdfFun);
        peakMRD = double(peakMRD(1));
        if ~isfinite(peakMRD), error('Nonfinite maximum MRD.'); end
        xyz = [double(peakDir.x),double(peakDir.y),double(peakDir.z)];
        xyz = xyz(1,:);
        if xyz(3)<0, xyz = -xyz; end % antipodal equivalent
        xyz = xyz/norm(xyz);
        peakXYZ = xyz;
        tiltDeg = acos(max(-1,min(1,xyz(3))))/degree;
        if hypot(xyz(1),xyz(2)) > 1e-10
            azDeg = mod(atan2(xyz(2),xyz(1))/degree,360);
        end
    catch ME
        warning('Could not calculate a PF maximum/direction: %s',ME.message);
    end
end


