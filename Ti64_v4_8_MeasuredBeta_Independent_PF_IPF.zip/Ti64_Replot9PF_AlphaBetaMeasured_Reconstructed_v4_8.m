function Ti64_Replot9PF_AlphaBetaMeasured_Reconstructed_v4_8()
% Re-create Figure 25 (9 pole figures in 3 rows) using a previously saved
% prior-beta reconstruction MAT and the ORIGINAL .ctf file. Does NOT re-run BOR.
% Rows: matched measured alpha; ALL originally measured beta; matched
% reconstructed parent beta. Includes peak MRD and direction CSV.
% Requires MTEX startup. Run: Ti64_Replot9PF_AlphaBetaMeasured_Reconstructed
% Opens an independent normal MATLAB window, not an overlay on Fig. 12/13.

    if exist('EBSD','class') ~= 8 || exist('calcDensity','file') == 0
        error('Start MTEX before running this function (startup_mtex).');
    end

    [fn,fp] = uigetfile('*.mat','Select ParentBeta_v4_BOR_Schmid_Workspace.mat');
    if isequal(fn,0), return; end
    D=load(fullfile(fp,fn),'Rsave','settings');
    if ~isfield(D,'Rsave') || ~isfield(D.Rsave,'rec')
        error('Saved MAT file must contain Rsave.rec.');
    end
    R = D.Rsave;
    betaReconstructed = R.rec;
    if isempty(betaReconstructed), error('No reconstructed beta pixels in MAT file.'); end

    ctfFile = '';
    if isfield(D,'settings') && isfield(D.settings,'inputFile')
        ctfFile = D.settings.inputFile;
    end
    if ~isfile(ctfFile)
        [ctfName,ctfPath] = uigetfile('*.ctf','Select ORIGINAL CTF of the same scan');
        if isequal(ctfName,0), return; end
        ctfFile=fullfile(ctfPath,ctfName);
    end

    raw = EBSD.load(ctfFile,'interface','ctf', ...
        'convertEuler2SpatialReferenceFrame');
    alphaMeasured = raw('Ti-Hex');
    csAlpha = alphaMeasured.CS;
    csBeta = betaReconstructed.CS;
    selected = alphaMeasured(ismember(alphaMeasured.id,betaReconstructed.id));
    if length(selected) ~= length(betaReconstructed) || ...
            ~isequal(sort(selected.id(:)),sort(betaReconstructed.id(:)))
        error(['CTF does not match the reconstructed beta pixels in MAT. ', ...
               'Use original CTF of the same EBSD scan.']);
    end
    % Sorting is essential to confirm paired spatial correspondence.
    [~,ia] = sort(selected.id(:));
    [~,ib] = sort(betaReconstructed.id(:));
    selected = selected(ia);
    betaReconstructed = betaReconstructed(ib);
    if any(abs(selected.x(:)-betaReconstructed.x(:))>1e-6) || ...
       any(abs(selected.y(:)-betaReconstructed.y(:))>1e-6)
        error('Alpha/beta matched IDs do not have identical spatial locations.');
    end

    coverage = 100*length(selected)/max(1,length(alphaMeasured));
    nFrag=NaN;
    if isfield(R,'frag') && isfield(R.frag,'n')
        nFrag=R.frag.n;
    end
    fprintf('Matched pairs: %d / %d alpha (%.2f%%)\n', ...
        length(selected),length(alphaMeasured),coverage);
    betaMeasured = raw('Titanium cubic');
    fprintf('Original measured beta: %d pixels\n',length(betaMeasured));
    try
        fig = plotNinePF_MeasuredAndReconstructedBeta( ...
            selected.orientations,betaMeasured.orientations, ...
            betaReconstructed.orientations,csAlpha,csBeta, ...
            10*degree,coverage,fp);
        set(fig,'WindowStyle','normal','Visible','on');
        figure(fig); drawnow;
    catch ME25
        warning('Figure 25 failed; independent beta PF/IPF figures will still be made: %s',ME25.message);
    end
    % These two independent windows display ONLY measured beta, so even if
    % the nine-panel plot is hidden or closed, its data remain accessible.
    [figPF,figIPF] = plotMeasuredBetaPFandIPF( ...
        betaMeasured,10*degree,fp);
    if ~isempty(figIPF), figure(figIPF); drawnow; end

end



%% ===== NINE POLE FIGURES: measured alpha, measured beta, reconstructed beta =====
function figH = plotNinePF_MeasuredAndReconstructedBeta( ...
    oriAlphaMatched,oriBetaMeasured,oriBetaReconstructed, ...
    csAlpha,csBeta,halfwidth,coveragePct,outFolder)
% Figure 25 is independent of Figure 12 and Figure 13 (own handle + tag).
% Row 1: measured alpha from the MATCHED reconstructed-alpha pixels ONLY.
% Row 2: ALL beta pixels MEASURED in the original CTF (NOT reconstructed).
% Row 3: reconstructed parent beta from the SAME matched alpha pixels as row 1.
% WARNING: row 2 is a different spatial population from rows 1 and 3.
% The measured-beta pixels are spatially correlated; counting each as an
% independent grain overstates effective texture sample size.

    if isempty(oriAlphaMatched) || isempty(oriBetaReconstructed)
        error('Figure 25 needs both matched alpha and reconstructed beta.');
    end
    if numel(oriAlphaMatched)~=numel(oriBetaReconstructed)
        error('Figure 25: alpha/beta reconstructed pixel counts do not match.');
    end

    ha = [Miller(0,0,0,2,csAlpha), ...
          Miller(1,0,-1,0,csAlpha), ...
          Miller(1,1,-2,0,csAlpha)];
    hb = [Miller(1,1,0,csBeta),Miller(2,0,0,csBeta), ...
          Miller(2,1,1,csBeta)];
    hByRow = {ha,hb,hb};
    labelsByRow = {{'{0002}','{10-10}','{11-20}'}, ...
                   {'{110}','{200}','{211}'}, ...
                   {'{110}','{200}','{211}'}};
    rowNames = {'Measured alpha (matched)', ...
                'Measured beta (original CTF)', ...
                'Reconstructed parent beta'};
    oriByRow = {oriAlphaMatched,oriBetaMeasured,oriBetaReconstructed};
    pixelCounts = [numel(oriAlphaMatched),numel(oriBetaMeasured), ...
                   numel(oriBetaReconstructed)];
    odfByRow = cell(1,3);
    available = false(1,3);
    for r=1:3
        if pixelCounts(r)==0
            warning('Figure 25: %s has ZERO pixels in the CTF.',rowNames{r});
            continue;
        end
        try
            odfByRow{r} = calcDensity(oriByRow{r}, ...
                'halfwidth',halfwidth,'silent');
            available(r) = true;
        catch MEodf
            warning('Figure 25: ODF failed for %s: %s', ...
                rowNames{r},MEodf.message);
        end
    end
    if ~available(1) || ~available(3)
        error('Figure 25: failed to compute alpha or reconstructed-beta ODF.');
    end
    if pixelCounts(2)>0 && pixelCounts(2)<100
        warning(['Only %d measured-beta EBSD pixels. Measured-beta PF ', ...
                 'is not a robust texture estimate.'],pixelCounts(2));
    end

    figH = figure('Name','25 | NINE PF - alpha / measured beta / reconstructed beta', ...
        'NumberTitle','off','Color','white','Visible','on', ...
        'WindowStyle','normal','Tag','Ti64_NinePF_Fig25', ...
        'Units','pixels','Position',[120 90 1580 1000]);
    axs = gobjects(3,3);
    phaseNames = cell(9,1); familyNames = cell(9,1);
    maxValues = nan(9,1); xyz = nan(9,3);
    tiltVals = nan(9,1); azVals = nan(9,1);
    pixVals = zeros(9,1); halfVals = repmat(halfwidth/degree,9,1);

    for r=1:3
        for k=1:3
            q=(r-1)*3+k;
            phaseNames{q}=rowNames{r};
            familyNames{q}=labelsByRow{r}{k};
            pixVals(q)=pixelCounts(r);
            figure(figH);
            axs(r,k) = subplot(3,3,q,'Parent',figH);
            if available(r)
                [maxValues(q),xyz(q,:),tiltVals(q),azVals(q)] = ...
                    pfMaxWithDirection(odfByRow{r},hByRow{r}(k));
                plotPDF(odfByRow{r},hByRow{r}(k), ...
                    'antipodal','contourf','parent',axs(r,k));
                title(axs(r,k),sprintf('%s %s | max %.2f MRD', ...
                    rowNames{r},familyNames{q},maxValues(q)), ...
                    'FontSize',9,'FontWeight','bold','Interpreter','none');
            else
                axis(axs(r,k),'off');
                text(axs(r,k),0.5,0.5,'No indexed measured beta', ...
                    'Units','normalized','HorizontalAlignment','center', ...
                    'FontSize',10);
                title(axs(r,k),sprintf('%s %s | no data', ...
                    rowNames{r},familyNames{q}), ...
                    'Interpreter','none','FontSize',9);
            end
        end
    end
    drawnow;
    if any(~isgraphics(axs(:),'axes'))
        error('Figure 25: plotPDF replaced one or more of the nine axes.');
    end

    % Consistent MRD color limit within each phase/source ROW, NOT across
    % different populations: absolute MRD amplitudes remain in plot titles.
    for r=1:3
        if ~available(r), continue; end
        localUpper = zeros(1,3);
        for k=1:3
            lim = get(axs(r,k),'CLim');
            localUpper(k)=lim(2);
        end
        p=maxValues((r-1)*3+(1:3));
                % MATLAB can return one limit array as a column and another as
        % a row.  Concatenate COLUMN vectors to prevent horzcat errors.
        validLimits = localUpper(isfinite(localUpper));
        validPeaks = p(isfinite(p));
        allCandidates = [validLimits(:);validPeaks(:)];
        if isempty(allCandidates)
            upper = 1;
        else
            upper = max(allCandidates);
        end
        if isempty(upper) || ~isfinite(upper) || upper<=0, upper=1; end
        for k=1:3
            set(axs(r,k),'CLim',[0 upper]);
        end
        cb=colorbar(axs(r,3),'eastoutside');
        ylabel(cb,sprintf('MRD (row %d)',r));
    end

    try
        sgtitle(figH,sprintf(['Alpha (matched): %d pixels (%.2f%% coverage) | ', ...
            'Beta measured: %d pixels | Beta reconstructed: %d pixels'], ...
            pixelCounts(1),coveragePct,pixelCounts(2),pixelCounts(3)), ...
            'Interpreter','none','FontWeight','bold');
    catch
    end
    drawnow;

    T=table(phaseNames,familyNames,maxValues, ...
        xyz(:,1),xyz(:,2),xyz(:,3),tiltVals,azVals,pixVals,halfVals, ...
        'VariableNames',{'PhaseSource','PoleFamily','MaxMRD', ...
        'PeakDir_X','PeakDir_Y','PeakDir_Z', ...
        'TiltFromZ_deg','AzimuthFromX_deg','EBSD_Pixels','ODFHalfwidth_deg'});
    fprintf('\n===== FIGURE 25: NINE PF MAXIMA (MRD) =====\n');
    disp(T);
    fprintf(['Row 2 uses ALL originally MEASURED beta pixels; rows 1 and 3 ', ...
             'use only corresponding reconstructed alpha pixels.\n']);
    try
        writetable(T,fullfile(outFolder,'25_PF_MaxMRD_and_PeakDirections.csv'));
    catch MEcsv
        warning('Figure 25 CSV export failed: %s',MEcsv.message);
    end
    pngFile=fullfile(outFolder,'25_PF_AlphaMeasured_BetaMeasured_BetaReconstructed.png');
    figFile=fullfile(outFolder,'25_PF_AlphaMeasured_BetaMeasured_BetaReconstructed.fig');
    % Save a handle explicitly: never use gcf (the coverage map may be active).
    try
        exportgraphics(figH,pngFile,'Resolution',300);
    catch MEpng
        warning('Figure 25 PNG export failed: %s',MEpng.message);
    end
    try
        savefig(figH,figFile);
    catch MEfig
        warning('Figure 25 FIG export failed: %s',MEfig.message);
    end
    fprintf('Figure 25: %s\n',pngFile);
    fprintf('Figure 25 editable FIG: %s\n',figFile);
end

%% -------- Maximum of an MTEX pole density function ----------------------
function [peakMRD,peakXYZ,tiltDeg,azDeg] = pfMaxWithDirection(odf,h)
% Evaluates the maximum of the spherical POLE DENSITY FUNCTION, not the ODF.
% [value,direction] = max(calcPDF(odf,h)) is supported by MTEX S2Fun.max.
% The corresponding antipodal vector is flipped into the upper hemisphere,
% i.e., +Z-facing direction in the EBSD specimen reference frame.
    peakMRD = NaN;
    peakXYZ = [NaN NaN NaN];
    tiltDeg = NaN;
    azDeg = NaN;
    try
        pdfFun = calcPDF(odf,h);
        [peakMRD,peakDir] = max(pdfFun);
        peakMRD = double(peakMRD(1));
        if ~isfinite(peakMRD), error('Nonfinite maximum MRD.'); end
        xyz = [double(peakDir.x),double(peakDir.y),double(peakDir.z)];
        xyz = xyz(1,:);
        if xyz(3)<0, xyz = -xyz; end % antipodal equivalent
        xyz = xyz/norm(xyz);
        peakXYZ = xyz;
        tiltDeg = acos(max(-1,min(1,xyz(3))))/degree;
        if hypot(xyz(1),xyz(2)) > 1e-10
            azDeg = mod(atan2(xyz(2),xyz(1))/degree,360);
        end
    catch ME
        warning('Could not calculate a PF maximum/direction: %s',ME.message);
    end
end


%% ===== STANDALONE ORIGINAL MEASURED BETA: 3 PF + 3 IPF =====
function [figPF,figIPF] = plotMeasuredBetaPFandIPF(betaMeasured,halfwidth,outFolder)
% betaMeasured MUST be EBSD('Titanium cubic') from the original CTF.
% Figure 26: pole figures of {110}, {200}, {211} beta.
% Figure 27: inverse pole figures for the specimen directions X, Y, Z.
% These describe the original retained beta, NOT reconstructed prior beta.
% All three panels in each figure have their own explicit axes.
    figPF=[]; figIPF=[];
    n=length(betaMeasured);
    if n==0
        warning('No measured beta is indexed in the original CTF: figures 26/27 skipped.');
        return;
    end
    cs=betaMeasured.CS;
    odf=calcDensity(betaMeasured.orientations,'halfwidth',halfwidth,'silent');
    h=[Miller(1,1,0,cs),Miller(2,0,0,cs),Miller(2,1,1,cs)];
    labels={'{110}','{200}','{211}'};
    peakVals=nan(3,1); xyz=nan(3,3);
    tilt=nan(3,1); az=nan(3,1);

    %% Figure 26 - measured beta ONLY: three pole figures.
    figPF=figure('Name','26 | ORIGINAL MEASURED beta - 3 PFs', ...
        'NumberTitle','off','Color','white','Visible','on', ...
        'WindowStyle','normal','Tag','Ti64_MeasuredBeta_3PF_Fig26', ...
        'Units','pixels','Position',[180 160 1450 560]);
    axPF=gobjects(1,3);
    for k=1:3
        axPF(k)=subplot(1,3,k,'Parent',figPF);
        [peakVals(k),xyz(k,:),tilt(k),az(k)]=pfMaxWithDirection(odf,h(k));
        plotPDF(odf,h(k),'antipodal','contourf','parent',axPF(k));
        title(axPF(k),sprintf('Measured beta %s | max %.2f MRD', ...
            labels{k},peakVals(k)),'FontSize',11,'Interpreter','none');
    end
    drawnow;
    if any(~isgraphics(axPF,'axes'))
        warning('Figure 26: unexpected axes replacement by MTEX.');
    end
    tops=nan(3,1);
    for k=1:3
        lim=get(axPF(k),'CLim');
        tops(k)=lim(2);
    end
    allM=[tops(isfinite(tops));peakVals(isfinite(peakVals))];
    if isempty(allM), scale=1; else, scale=max(allM); end
    if ~isfinite(scale) || scale<=0, scale=1; end
    for k=1:3, set(axPF(k),'CLim',[0 scale]); end
    c=colorbar(axPF(3),'eastoutside'); ylabel(c,'MRD');
    try
        sgtitle(figPF,sprintf('ORIGINAL measured beta (CTF): %d indexed pixels | PF halfwidth %.1f deg', ...
            n,halfwidth/degree),'FontWeight','bold');
    catch
    end
    drawnow;
    T=table(labels(:),peakVals,xyz(:,1),xyz(:,2),xyz(:,3),tilt,az, ...
        repmat(n,3,1),repmat(halfwidth/degree,3,1), ...
        'VariableNames',{'PoleFamily','MaxMRD','PeakDir_X','PeakDir_Y', ...
        'PeakDir_Z','TiltFromZ_deg','AzimuthFromX_deg', ...
        'EBSD_Pixels','ODFHalfwidth_deg'});
    disp('===== ORIGINAL MEASURED BETA - THREE POLE FIGURE PEAKS =====');
    disp(T);
    writetable(T,fullfile(outFolder,'26_MeasuredBeta_PF_MaxMRD.csv'));
    exportgraphics(figPF,fullfile(outFolder,'26_MeasuredBeta_3PF.png'),'Resolution',300);
    savefig(figPF,fullfile(outFolder,'26_MeasuredBeta_3PF.fig'));

    %% Figure 27 - measured beta ONLY: three INVERSE pole figures.
    figIPF=figure('Name','27 | ORIGINAL MEASURED beta - IPF-X/Y/Z', ...
        'NumberTitle','off','Color','white','Visible','on', ...
        'WindowStyle','normal','Tag','Ti64_MeasuredBeta_3IPF_Fig27', ...
        'Units','pixels','Position',[220 205 1450 560]);
    axesIPF=gobjects(1,3);
    dirs=[xvector,yvector,zvector];
    dlabels={'X','Y','Z'};
    for k=1:3
        axesIPF(k)=subplot(1,3,k,'Parent',figIPF);
        plotIPDF(odf,dirs(k),'contourf','parent',axesIPF(k));
        title(axesIPF(k),sprintf('Measured beta | IPF-%s',dlabels{k}), ...
            'FontSize',11,'Interpreter','none');
    end
    drawnow;
    limits=nan(3,1);
    for k=1:3
        lim=get(axesIPF(k),'CLim');
        limits(k)=lim(2);
    end
    upper=limits(isfinite(limits));
    if isempty(upper), upper=1; else, upper=max(upper); end
    if ~isfinite(upper) || upper<=0, upper=1; end
    for k=1:3, set(axesIPF(k),'CLim',[0 upper]); end
    c=colorbar(axesIPF(3),'eastoutside'); ylabel(c,'MRD');
    try
        sgtitle(figIPF,sprintf('Inverse pole density: MEASURED beta only | %d indexed pixels',n), ...
            'FontWeight','bold');
    catch
    end
    drawnow;
    exportgraphics(figIPF,fullfile(outFolder,'27_MeasuredBeta_IPF_XYZ.png'),'Resolution',300);
    savefig(figIPF,fullfile(outFolder,'27_MeasuredBeta_IPF_XYZ.fig'));
    fprintf('Figure 26: 3 measured beta PF saved.\n');
    fprintf('Figure 27: 3 measured beta IPF saved.\n');
end
