Ti-6Al-4V | Measured-beta independent PF and IPF plots | v4.8

WHAT WAS FIXED
- Figure 25 error "Dimensions of arrays being concatenated are not consistent".
  The MRD upper bounds and PF maxima are now concatenated as column vectors.
- Measured beta (the beta directly indexed in original .ctf) now has separate figures:
  Figure 26: three conventional pole figures {110}, {200}, {211}, maxima in MRD.
  Figure 27: three inverse pole figures for sample X, Y, Z, with MRD colorbar.
- Figures 26/27 use measured beta only; never reconstructed beta pixels.
- The figures have independent undocked windows with their own handles.
- Figure 12 (six paired PF) and Figure 13 (coverage) are unchanged in purpose.

OPTION A: NO BETA RECONSTRUCTION NEEDED (RECOMMENDED TO CHECK RIGHT AWAY)
1. Start MTEX in MATLAB.
2. Put Ti64_MeasuredBeta_Standalone.m on your MATLAB path.
3. Run: Ti64_MeasuredBeta_Standalone
4. Select original CTF (Sample7(1).ctf or AB.ctf).
5. Output folder: [sample name]_MeasuredBeta_PF_IPF beside the CTF.

OPTION B: FULL PRIOR BETA RECONSTRUCTION
1. Use Ti64_ParentBeta_Reconstruction_MTEX611_v4_8_SeparateMeasuredBetaPF_IPF.m
2. Check mtexRoot at top of script for your full MTEX installation.
3. Run and choose original CTF; new figures 26 and 27 are made during the run.

OPTION C: REPLOT EXISTING RECONSTRUCTION WITHOUT RECOMPUTING BOR
1. Run Ti64_Replot9PF_AlphaBetaMeasured_Reconstructed_v4_8
2. Select ParentBeta_v4_BOR_Schmid_Workspace.mat and original CTF if asked.
3. Figures 25, 26 and 27 should appear.

OUTPUTS
26_MeasuredBeta_3PF.png / .fig
26_MeasuredBeta_PF_MaxMRD.csv
27_MeasuredBeta_IPF_XYZ.png / .fig

IMPORTANT: PF and IPF are DIFFERENT:
- PF gives specimen directions of {hkl} plane normals.
- IPF gives crystal directions along the specimen X/Y/Z axes.
- β here is retained/measured beta, not prior beta inferred using BOR.

NOTE: Files were edited statically; MATLAB/MTEX are not installed in this environment,
so you should validate figure output locally.
